package com.cognizant.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.model.User;

@Controller
@SessionAttributes("user")
public class ModelMapController {
	@RequestMapping(value="handler1.htm",method=RequestMethod.GET)
	public ModelAndView handlerMethod1(ModelMap map){
		
		User user=new User();
		user.setUserName("sabbir123");
		user.setFirstName("sabbir");
		user.setLastName("poonawala");

		map.addAttribute("user", user);
		ModelAndView mv=new ModelAndView();
		mv.setViewName("firstview");
		return mv;
	}
	
	@RequestMapping(value="handler2.htm",method=RequestMethod.GET)
	public ModelAndView handlerMethod2(@ModelAttribute("user")User user){
		
		ModelAndView mv=new ModelAndView();
		mv.addObject("user",user);
		mv.setViewName("secondview");
		return mv;

	}

}
